sap.ui.define([
    "./App.controller"
],
    function (Controller) {
        "use strict";

        return Controller.extend("zprpoinbox.controller.DisplayPRHeaderTable", {

            onInit: function () { },

            // onDisplayPRHeaderTableNavPress: function () {
            //     var sPrNumber = this.getModel("Inbox").getProperty("/PRNumber");
            //     this.getRouter().navTo("RequisitionDetails", {
            //         PrNumber: sPrNumber
            //     });
                
            // }
        });
    });
