sap.ui.define([
    "./App.controller",
    "zprpoinbox/model/models",
    "sap/m/MessageBox"
],
    function (Controller, Models, MessageBox) {
        "use strict";

        return Controller.extend("zprpoinbox.controller.POScheduling", {

            onInit: function () {
                this.getModel().setUseBatch(false);
                this.getRouter().getRoute("POScheduling").attachPatternMatched(this._onPatternMatched, this);
            },

            // on po scheduling pattern matched
            _onPatternMatched: async function () {
                var oRequisitionRoute = this.getRouter().getRoute("POScheduling");
                var sPattern = oRequisitionRoute._oRouter.getHashChanger().hash;
                this.getModel("Inbox").setProperty("/PoNumber",sPattern.split("/")[1]);
                var sPONumber = this.getModel("Inbox").getProperty("/PoNumber",sPONumber);
                this._readPOHeaderDetailTable("PoNumber", sPONumber);
            },

            // get table of PO scheduling page
            _readPOHeaderDetailTable: function (sProperty, sPONumber) {
                var operator = sap.ui.model.FilterOperator.EQ;;
                var oPONumberFilter = this.getFilter(sProperty, sPONumber, operator);
                var oPRPOModel = this.getODataModel();
                // var oPOTable = this.getControl("purchaseOrderTable");
                // this.showBusyControl(oPOTable);
                this.showBusyIndicator();
                oPRPOModel.read("/POItemDetailsSet", {
                    filters: [oPONumberFilter],
                    success: function (oData) {
                        var oInboxModel = this.getModel("Inbox");
                        oInboxModel.setProperty("/POHeaderTable", oData.results);
                        // oInboxModel.setProperty("/ItemCount", oData.results.length);
                        // this.hideBusyControl(oPOTable);
                        this.hideBusyIndicator()
                    }.bind(this),
                    error: function () { }
                });
            },

            // on nav back btn press (po scheduling view)
            onPOSchedulingNavPress: function () {
                this.getRouter().navTo("RouteApp");
            },

            // on table upadte finish (po scheduling view)
            onUpdateFinished: function (oEvent) {
                var iItemCount = oEvent.mParameters.total;
                var oInboxModel = this.getModel("Inbox");
                var sList = oInboxModel.getProperty("/ActiveList");
                sList === "PO" ? oInboxModel.setProperty("/POItemCount", iItemCount) : oInboxModel.setProperty("/REQItemCount", iItemCount);
            },

            // on po table item select
            onPOTableItemSelectionChange: function (oEvent) {
                var oListItem = oEvent.mParameters.listItem;
                oListItem.setSelected(false);
                var oSelectedPOTableObj = oListItem.getBindingContext("Inbox").getObject();
                this.getModel("Inbox").setProperty("/oSelectedPOTableObj", oSelectedPOTableObj);
                this.getRouter().navTo("POItem", {
                    PoItem: oSelectedPOTableObj.PoItem
                });
            },

            // po approve function
            _approvePO: function (sPONumber, sReleaseCode) {
                return new Promise(function (resolve, reject) {
                    var oInboxModel = this.getModel("Inbox");
                    oInboxModel.setProperty("/POApprovalObj", Models.getPOApprovalObj());
                    var oPOApprovalObj = oInboxModel.getProperty("/POApprovalObj");
                    oPOApprovalObj.PoNumber = sPONumber;
                    oPOApprovalObj.PoRelCod = sReleaseCode;
                    this.getODataModel().create("/POApproveSet", oPOApprovalObj, {
                        success: function (oData) {
                            resolve(oData);
                            var sPOApprovalSuccessMsg = this.getResourceBundle().getText("POApprovalSuccessMsg");
                            MessageBox.success(sPOApprovalSuccessMsg, {
                                actions: MessageBox.Action.OK,
                                onClose: function (Action) {
                                    if (Action === MessageBox.Action.OK) {
                                        this.onPOSchedulingNavPress();
                                        var sVisibleList = oInboxModel.getProperty("/ActiveList");
                                        sVisibleList === "PO" ? this._readPOListItem("EmailId", this.getUserInfo(), 'IN') : this._readPRListItem();
                                    }
                                }.bind(this),
                                dependentOn: this.getView()
                            });
                        }.bind(this),
                        error: function (oError) {
                        }
                    });
                }.bind(this));
            },

            // on approve press (po scheduling view)
            onPOApprovePress: function () {
                var oInboxModel = this.getModel("Inbox");
                var sPONo = oInboxModel.getProperty("/oSelectedPO").PoNumber;
                var sDialogTitleText = this.getResourceBundle().getText("confirmationTitle");
                var sMsgText = this.getResourceBundle().getText("POApproveDialogMsgTxt") + `${sPONo} ?`;
                var sCancelBtnText = this.getResourceBundle().getText("cancelBtn");
                var sOkBtnText = this.getResourceBundle().getText("okBtn");
                if (!this.oApproveMsgDialog) {
                    this.oApproveMsgDialog = new sap.m.Dialog({
                        type: sap.m.DialogType.Message,
                        title: sDialogTitleText,
                        content: new sap.m.Text({
                            text: sMsgText
                        }),
                        beginButton: new sap.m.Button({
                            text: sCancelBtnText,
                            icon: "sap-icon://decline",
                            type: "Negative",
                            press: function () {
                                this.closeApproveMsgDialog();
                            }.bind(this)
                        }),
                        endButton: new sap.m.Button({
                            type: "Success",
                            text: sOkBtnText,
                            press: async function () {
                                var oInboxModel = this.getModel("Inbox");
                                var sPONumber = oInboxModel.getProperty("/oSelectedPO").PoNumber;
                                var sReleaseCode = oInboxModel.getProperty("/oSelectedPO").ReleaseCode;
                                await this._approvePO(sPONumber, sReleaseCode);
                                this.closeApproveMsgDialog();
                            }.bind(this)
                        })
                    });
                    this.getView().addDependent(this.oApproveMsgDialog);
                    this.oApproveMsgDialog.open();
                }
                this.oApproveMsgDialog.open();
            },

            // po reject function
            _rejectPO: function (sPONumber) {
                return new Promise(function (resolve, reject) {
                    var oInboxModel = this.getModel("Inbox");
                    oInboxModel.setProperty("/PORejectObj", Models.getPORejectionObj());
                    var oPORejectObj = oInboxModel.getProperty("/PORejectObj");
                    oPORejectObj.PoNumber = sPONumber;
                    this.getODataModel().create("/PORejectSet", oPORejectObj, {
                        success: function (oData) {
                            resolve(oData);
                            // var sPORejectionSuccessMsg = this.getResourceBundle().getText("PORejectionSuccessMsg");
                            MessageBox.success(oData.Message, {
                                actions: MessageBox.Action.OK,
                                onClose: function (Action) {
                                    if (Action === MessageBox.Action.OK) {
                                        this.onPOSchedulingNavPress();
                                        var sVisibleList = oInboxModel.getProperty("/ActiveList");
                                        sVisibleList === "PO" ? this._readPOListItem("EmailId", this.getUserInfo(), 'IN') : this._readPRListItem();
                                    }
                                }.bind(this),
                                dependentOn: this.getView()
                            });
                        }.bind(this),
                        error: function (oError) {
                        }
                    });
                }.bind(this));
            },

            // on cancel press (po scheduling view)
            onPORejectPress: function () {
                var oInboxModel = this.getModel("Inbox");
                var sPONo = oInboxModel.getProperty("/oSelectedPO").PoNumber;
                var sDialogTitleText = this.getResourceBundle().getText("confirmationTitle");
                var sMsgText = this.getResourceBundle().getText("PORejectDialogMsgTxt") + `${sPONo} ?`;
                var sCancelBtnText = this.getResourceBundle().getText("cancelBtn");
                var sOkBtnText = this.getResourceBundle().getText("okBtn");
                if (!this.oRejectMsgDialog) {
                    this.oRejectMsgDialog = new sap.m.Dialog({
                        type: sap.m.DialogType.Message,
                        title: sDialogTitleText,
                        content: new sap.m.Text({
                            text: sMsgText
                        }),
                        beginButton: new sap.m.Button({
                            text: sCancelBtnText,
                            icon: "sap-icon://decline",
                            type: "Negative",
                            press: function () {
                                this.closeRejectMsgDialog();
                            }.bind(this)
                        }),
                        endButton: new sap.m.Button({
                            type: "Success",
                            text: sOkBtnText,
                            press: async function () {
                                var oInboxModel = this.getModel("Inbox");
                                var sPONumber = oInboxModel.getProperty("/oSelectedPO").PoNumber;
                                this.closeRejectMsgDialog();
                                await this._rejectPO(sPONumber);
                            }.bind(this)
                        })
                    });
                    this.getView().addDependent(this.oRejectMsgDialog);
                    this.oRejectMsgDialog.open();
                }
                this.oRejectMsgDialog.open();
            },

            // get user details
            getUserInfo: function () {
                if (window.location.href.includes("applicationstudio.cloud.sap")) {
                    return "pankaj_mishra@pall.com";
                    return "vishnu_chukkareddy@europe.pall.com";
                    return "kishor_donge@pall.com";
                } else {
                    var oUserInfo = sap.ushell.Container.getService("UserInfo"),
                        sId = oUserInfo.getId(),
                        sEmail = oUserInfo.getEmail(),
                        oUser = {
                            "ID": sId,
                            "EMAIL": sEmail
                        };
                    this.getModel("Inbox").setProperty("/UserDetails", oUser);
                    return sEmail;
                }

            },

            // get PO list item (main view)
            _readPOListItem: function (sProperty, sUserId, sParameter) {
                if (!sParameter) {
                    sParameter = 'IN'
                }
                var operator = sap.ui.model.FilterOperator.EQ;
                var oUserIdFilter = this.getFilter(sProperty, sUserId, operator);
                var oTaskObjFilter = this.getFilter("TaskObj", "TS99900033", operator);
                var oParameterFilter = this.getFilter("Parameter", sParameter, operator);
                var oPRPOModel = this.getODataModel();
                oPRPOModel.read("/POWorkItemsSet", {
                    filters: [oUserIdFilter, oTaskObjFilter, oParameterFilter],
                    success: function (oData) {
                        var oInboxModel = this.getModel("Inbox");
                        oInboxModel.setProperty("/POs", oData.results);
                        oInboxModel.refresh(true);
                    }.bind(this),
                    error: function () {
                        var oControl = oInboxModel.getProperty("/oControl");
                        this.hideBusyControl(oControl);
                    }.bind(this)
                });
            },

            // get PR list item (main view)
            _readPRListItem: function () {
                var operator = sap.ui.model.FilterOperator.EQ;
                var sParameter;
                if (!sParameter) {
                    sParameter = 'IN'
                }
                var oUserIdFilter = this.getFilter("EmailId", this.getUserInfo(), operator);
                var oTaskObjFilter = this.getFilter("TaskObj", "TS99900012", operator);
                var oParameterFilter = this.getFilter("Parameter", sParameter, operator);
                var oPRPOModel = this.getODataModel();                
                oPRPOModel.read("/POWorkItemsSet", {
                    filters: [oUserIdFilter, oTaskObjFilter, oParameterFilter],
                    success: function (oData) {
                        var oInboxModel = this.getModel("Inbox");
                        oInboxModel.setProperty("/PRs", oData.results);
                        oInboxModel.refresh(true);
                    }.bind(this),
                    error: function () { }
                });
            },

            onDisplayPOHeaderTableNavPress: function () {
                var sPoNumber = this.getModel("Inbox").getProperty("/PoNumber");
                this.getRouter().navTo("POScheduling", {
                    PoNumber: sPoNumber
                });
            }
        });
    });
