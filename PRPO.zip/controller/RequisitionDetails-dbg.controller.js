sap.ui.define([
    "./App.controller",
    "zprpoinbox/model/models",
    "sap/m/MessageBox"
],
    function (Controller, Models, MessageBox) {
        "use strict";

        return Controller.extend("zprpoinbox.controller.RequisitionDetails", {

            onInit: function () {
                this.getModel().setUseBatch(false);
                this.getRouter().getRoute("RequisitionDetails").attachPatternMatched(this._onPatternMatched, this);
            },

            // on requisition pattern matched
            _onPatternMatched: async function () {
                var oRequisitionRoute = this.getRouter().getRoute("RequisitionDetails");
                var sPattern = oRequisitionRoute._oRouter.getHashChanger().hash;
                this.getModel("Inbox").setProperty("/PRNumber", sPattern.split("/")[1]);
                var sPRNumber = this.getModel("Inbox").getProperty("/PRNumber", sPRNumber);
                this._readPRHeaderDetailTable("PrNumber", sPRNumber);
                await this._readPRHeaderDetailItem("PrNumber", sPRNumber);
            },

            // get header data item & form of PO scheduling page
            _readPRHeaderDetailItem: function (sProperty, sPRNumber) {
                return new Promise((resolve, reject) => {
                    var operator = sap.ui.model.FilterOperator.EQ;
                    var oPRNumberFilter = this.getFilter(sProperty, sPRNumber, operator);
                    var oPRPOModel = this.getODataModel();
                    // this.showBusyIndicator();
                    oPRPOModel.read("/PRHeaderDetailsSet", {
                        filters: [oPRNumberFilter],
                        success: function (oData) {
                            var oInboxModel = this.getModel("Inbox");
                            oInboxModel.setProperty("/oSelectedRequisition", oData.results[0]);
                            oInboxModel.setProperty("/ReleaseCode", oData.results[0].RelCode);
                            // oInboxModel.setProperty("/REQItemCount", oData.results.length);
                            oInboxModel.setProperty("/ActiveList", "REQ");
                            resolve(oData.results[0]);
                            // this.hideBusyIndicator();
                        }.bind(this),
                        error: function () { }
                    });
                });
            },

            // on nav btn back press
            onRequistionNavPress: function () {
                this.getRouter().navTo("RouteApp");
            },

            // on table (PO & PR) update finish
            onUpdateFinished: function (oEvent) {
                var iItemCount = oEvent.mParameters.total;
                var oInboxModel = this.getModel("Inbox");
                var sList = oInboxModel.getProperty("/ActiveList");
                sList === "PO" ? oInboxModel.setProperty("/POItemCount", iItemCount) : oInboxModel.setProperty("/REQItemCount", iItemCount);
            },

            // get table of requisition details page
            _readPRHeaderDetailTable: function (sProperty, sPRNumber) {
                var operator = sap.ui.model.FilterOperator.EQ;;
                var oPRNumberFilter = this.getFilter(sProperty, sPRNumber, operator);
                var oPRPOModel = this.getODataModel();
                var oPRTable = this.getControl("requisitionTable");
                oPRTable = oPRTable === undefined ? this.byId("requisitionTable") : this.getControl("requisitionTable");
                this.showBusyControl(oPRTable);
                oPRPOModel.read("/PRItemDetailsSet", {
                    filters: [oPRNumberFilter],
                    success: function (oData) {
                        var oInboxModel = this.getModel("Inbox");
                        oInboxModel.setProperty("/REQTableItems", oData.results);
                        oInboxModel.setProperty("/REQItemCount", oData.results.length);
                        this.hideBusyControl(oPRTable);
                    }.bind(this),
                    error: function () { }
                });
            },

            // on pr table item select
            onPRTableItemSelectionChange: function (oEvent) {
                var oListItem = oEvent.mParameters.listItem;
                oListItem.setSelected(false);
                var oSelectedPRTableObj = oListItem.getBindingContext("Inbox").getObject();
                this.getModel("Inbox").setProperty("/oSelectedPRTableObj", oSelectedPRTableObj);
                this.getRouter().navTo("PRItem");
            },

            // pr approve function
            _approvePR: function (sPRNumber, sReleaseCode) {
                return new Promise(function (resolve, reject) {
                    var oInboxModel = this.getModel("Inbox");
                    oInboxModel.setProperty("/PRApprovalObj", Models.getPRApprovalObj());
                    var oPRApprovalObj = oInboxModel.getProperty("/PRApprovalObj");
                    oPRApprovalObj.PrNumber = sPRNumber;
                    oPRApprovalObj.RelCode = sReleaseCode;
                    this.getODataModel().create("/PRApproveSet", oPRApprovalObj, {
                        success: function (oData) {
                            resolve(oData);
                            // var sPRApprovalSuccessMsg = this.getResourceBundle().getText("PRApprovalSuccessMsg");
                            MessageBox.success(oData.Message, {
                                actions: MessageBox.Action.OK,
                                onClose: function (Action) {
                                    if (Action === MessageBox.Action.OK) {
                                        this.onRequistionNavPress();
                                        var sVisibleList = oInboxModel.getProperty("/ActiveList");
                                        sVisibleList === "PO" ? this._readPOListItem("EmailId", this.getUserInfo(), 'IN') : this._readPRListItem();
                                    }
                                }.bind(this),
                                dependentOn: this.getView()
                            });
                        }.bind(this),
                        error: function (oError) { }
                    });
                }.bind(this));
            },

            // pr reject function
            _rejectPR: function (sPRNumber) {
                return new Promise(function (resolve, reject) {
                    var oInboxModel = this.getModel("Inbox");
                    oInboxModel.setProperty("/PRRejectionObj", Models.getPRRejectionObj());
                    var oPRRejectionObj = oInboxModel.getProperty("/PRRejectionObj");
                    oPRRejectionObj.PrNumber = sPRNumber;
                    this.getODataModel().create("/PRRejectSet", oPRRejectionObj, {
                        success: function (oData) {
                            resolve(oData);
                            MessageBox.success(oData.Message, {
                                actions: MessageBox.Action.OK,
                                onClose: function (Action) {
                                    if (Action === MessageBox.Action.OK) {
                                        this.onRequistionNavPress();
                                        var sVisibleList = oInboxModel.getProperty("/ActiveList");
                                        sVisibleList === "PO" ? this._readPOListItem("EmailId", this.getUserInfo(), 'IN') : this._readPRListItem();
                                    }
                                }.bind(this),
                                dependentOn: this.getView()
                            });
                        }.bind(this),
                        error: function (oError) {

                        }
                    });
                }.bind(this));
            },

            // on approve press (requisition details view)
            onRequisitionApprovePress: function () {
                var oInboxModel = this.getModel("Inbox");
                var sRequisitionNo = oInboxModel.getProperty("/oSelectedRequisition").PrNumber;
                var sDialogTitleText = this.getResourceBundle().getText("confirmationTitle");
                var sMsgText = this.getResourceBundle().getText("reqApproveDialogMsgTxt") + `${sRequisitionNo} ?`;
                var sCancelBtnText = this.getResourceBundle().getText("cancelBtn");
                var sOkBtnText = this.getResourceBundle().getText("okBtn");
                if (!this.oApproveMsgDialog) {
                    this.oApproveMsgDialog = new sap.m.Dialog({
                        type: sap.m.DialogType.Message,
                        title: sDialogTitleText,
                        content: new sap.m.Text({
                            text: sMsgText
                        }),
                        beginButton: new sap.m.Button({
                            text: sCancelBtnText,
                            icon: "sap-icon://decline",
                            type: "Negative",
                            press: function () {
                                this.closeApproveMsgDialog();
                            }.bind(this)
                        }),
                        endButton: new sap.m.Button({
                            type: "Success",
                            text: sOkBtnText,
                            press: async function () {
                                var oInboxModel = this.getModel("Inbox");
                                var sPRNumber = oInboxModel.getProperty("/PRNumber");
                                var sReleaseCode = oInboxModel.getProperty("/ReleaseCode");
                                this.closeApproveMsgDialog();
                                await this._approvePR(sPRNumber, sReleaseCode);
                            }.bind(this)
                        })
                    });
                    this.getView().addDependent(this.oApproveMsgDialog);
                    this.oApproveMsgDialog.open();
                }
                this.oApproveMsgDialog.open();
            },

            // on cancel press (requisition details view)
            onRequisitionRejectPress: function () {
                var oInboxModel = this.getModel("Inbox");
                var sRequisitionNo = oInboxModel.getProperty("/oSelectedRequisition").PrNumber;
                var sDialogTitleText = this.getResourceBundle().getText("confirmationTitle");
                var sMsgText = this.getResourceBundle().getText("reqRejectDialogMsgTxt") + `${sRequisitionNo} ?`;
                var sCancelBtnText = this.getResourceBundle().getText("cancelBtn");
                var sOkBtnText = this.getResourceBundle().getText("okBtn");
                if (!this.oRejectMsgDialog) {
                    this.oRejectMsgDialog = new sap.m.Dialog({
                        type: sap.m.DialogType.Message,
                        title: sDialogTitleText,
                        content: new sap.m.Text({
                            text: sMsgText
                        }),
                        beginButton: new sap.m.Button({
                            text: sCancelBtnText,
                            icon: "sap-icon://decline",
                            type: "Negative",
                            press: function () {
                                this.closeRejectMsgDialog();
                            }.bind(this)
                        }),
                        endButton: new sap.m.Button({
                            type: "Success",
                            text: sOkBtnText,
                            press: async function () {
                                var oInboxModel = this.getModel("Inbox");
                                var sPRNumber = oInboxModel.getProperty("/PRNumber");
                                this.closeRejectMsgDialog();
                                await this._rejectPR(sPRNumber);
                            }.bind(this)
                        })
                    });
                    this.getView().addDependent(this.oRejectMsgDialog);
                    this.oRejectMsgDialog.open();
                }
                this.oRejectMsgDialog.open();
            },

            // get user details
            getUserInfo: function () {
                if (window.location.href.includes("applicationstudio.cloud.sap")) {
                    return "pankaj_mishra@pall.com";
                    return "vishnu_chukkareddy@europe.pall.com";
                    return "kishor_donge@pall.com";
                } else {
                    var oUserInfo = sap.ushell.Container.getService("UserInfo"),
                        sId = oUserInfo.getId(),
                        sEmail = oUserInfo.getEmail(),
                        oUser = {
                            "ID": sId,
                            "EMAIL": sEmail
                        };
                    this.getModel("Inbox").setProperty("/UserDetails", oUser);
                    return sEmail;
                }

            },

            // get PO list item (main view)
            _readPOListItem: function (sProperty, sUserId, sParameter) {
                if (!sParameter) {
                    sParameter = 'IN'
                }
                var operator = sap.ui.model.FilterOperator.EQ;
                var oUserIdFilter = this.getFilter(sProperty, sUserId, operator);
                var oTaskObjFilter = this.getFilter("TaskObj", "TS99900033", operator);
                var oParameterFilter = this.getFilter("Parameter", sParameter, operator);
                var oPRPOModel = this.getODataModel();
                oPRPOModel.read("/POWorkItemsSet", {
                    filters: [oUserIdFilter, oTaskObjFilter, oParameterFilter],
                    success: function (oData) {
                        var oInboxModel = this.getModel("Inbox");
                        oInboxModel.setProperty("/POs", oData.results);
                        oInboxModel.refresh(true);
                    }.bind(this),
                    error: function () {
                        var oControl = oInboxModel.getProperty("/oControl");
                        this.hideBusyControl(oControl);
                    }.bind(this)
                });
            },

            // get PR list item (main view)
            _readPRListItem: function () {
                var operator = sap.ui.model.FilterOperator.EQ;
                var sParameter;
                if (!sParameter) {
                    sParameter = 'IN'
                }
                var oUserIdFilter = this.getFilter("EmailId", this.getUserInfo(), operator);
                var oTaskObjFilter = this.getFilter("TaskObj", "TS99900012", operator);
                var oParameterFilter = this.getFilter("Parameter", sParameter, operator);
                var oPRPOModel = this.getODataModel();
                oPRPOModel.read("/POWorkItemsSet", {
                    filters: [oUserIdFilter, oTaskObjFilter, oParameterFilter],
                    success: function (oData) {
                        var oInboxModel = this.getModel("Inbox");
                        oInboxModel.setProperty("/PRs", oData.results);
                        oInboxModel.refresh(true);
                    }.bind(this),
                    error: function () { }
                });
            },

            onDisplayPRHeaderTableNavPress: function () {
                var sPrNumber = this.getModel("Inbox").getProperty("/PRNumber");
                this.getRouter().navTo("RequisitionDetails", {
                    PrNumber: sPrNumber
                });

            }

        });
    });
