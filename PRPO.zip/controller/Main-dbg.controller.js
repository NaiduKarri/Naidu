sap.ui.define([
    "./App.controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "../model/models"
],
    function (Controller, Filter, FilterOperator, MessageBox, Models) {
        "use strict";

        return Controller.extend("zprpoinbox.controller.Main", {

            onInit: function () {
                this.getModel().setUseBatch(false);
                var oInboxModel = this.getModel("Inbox");
                oInboxModel.setProperty("/ActiveList", "PO");
                oInboxModel.setProperty("/bVisibleInSearch", true);
                var oRouter = this.getRouter();
                if (oRouter.getRoute("RouteApp").getPattern("") === ':?query:') {
                    oRouter.getRoute("RouteApp").attachPatternMatched(this._onPatternMatched, this);
                }
                var sVisibleList = oInboxModel.getProperty("/ActiveList");
                sVisibleList === "PO" ? this._readPOListItem("EmailId", this.getUserInfo(), 'IN') : this._readPRListItem();
            },

            // on main view pattern matched
            _onPatternMatched: function () {
                var oInboxModel = this.getModel("Inbox");
                var bRefreshed = oInboxModel.getProperty("/bRefreshed");
                if (bRefreshed) {
                    var sVisibleList = oInboxModel.getProperty("/ActiveList");
                    sVisibleList === "PO" ? this._readPOListItem("EmailId", this.getUserInfo(), 'IN') : this._readPRListItem();
                }

            },

            // get user details
            getUserInfo: function () {
                if (window.location.href.includes("applicationstudio.cloud.sap")) {
                    return "pankaj_mishra@pall.com";
                    // return "vishnu_chukkareddy@europe.pall.com";
                    // return "kishor_donge@pall.com";
                } else {
                    var oUserInfo = sap.ushell.Container.getService("UserInfo"),
                        sId = oUserInfo.getId(),
                        sEmail = oUserInfo.getEmail(),
                        oUser = {
                            "ID": sId,
                            "EMAIL": sEmail
                        };
                    this.getModel("Inbox").setProperty("/UserDetails", oUser);
                    return sEmail;
                }

            },

            // get PO list item (main view)
            _readPOListItem: function (sProperty, sUserId, sParameter) {
                if (!sParameter) {
                    sParameter = 'IN'
                }
                var operator = sap.ui.model.FilterOperator.EQ;
                var oUserIdFilter = this.getFilter(sProperty, sUserId, operator);
                var oTaskObjFilter = this.getFilter("TaskObj", "TS99900033", operator);
                var oParameterFilter = this.getFilter("Parameter", sParameter, operator);
                var oPRPOModel = this.getODataModel();
                var oInboxModel = this.getModel("Inbox");
                var sVisibleList = oInboxModel.getProperty("/ActiveList");
                var oList = sVisibleList === "PO" ? this.getControl("POList") : this.getControl("RequisitionList");
                oInboxModel.setProperty("/oControl", oList);
                var oControl = oInboxModel.getProperty("/oControl");
                this.showBusyControl(oControl);
                oPRPOModel.read("/POWorkItemsSet", {
                    filters: [oUserIdFilter, oTaskObjFilter, oParameterFilter],
                    success: function (oData) {
                        var oInboxModel = this.getModel("Inbox");
                        oInboxModel.setProperty("/bRefreshed", false);
                        oInboxModel.setProperty("/POs", oData.results);
                        var oControl = oInboxModel.getProperty("/oControl");
                        this.hideBusyControl(oControl);
                    }.bind(this),
                    error: function (oError) {
                        var oControl = oInboxModel.getProperty("/oControl");
                        this.hideBusyControl(oControl);
                    }.bind(this)
                });
            },

            // get PR list item (main view)
            _readPRListItem: function () {
                var operator = sap.ui.model.FilterOperator.EQ;
                var sParameter;
                if (!sParameter) {
                    sParameter = 'IN'
                }
                var oUserIdFilter = this.getFilter("EmailId", this.getUserInfo(), operator);
                var oTaskObjFilter = this.getFilter("TaskObj", "TS99900012", operator);
                var oParameterFilter = this.getFilter("Parameter", sParameter, operator);
                var oPRPOModel = this.getODataModel();
                var oInboxModel = this.getModel("Inbox");
                var sVisibleList = oInboxModel.getProperty("/ActiveList");
                var oList = sVisibleList === "PO" ? this.getControl("POList") : this.getControl("RequisitionList");
                oInboxModel.setProperty("/oControl", oList);
                var oControl = oInboxModel.getProperty("/oControl");
                this.showBusyControl(oControl);
                oPRPOModel.read("/POWorkItemsSet", {
                    filters: [oUserIdFilter, oTaskObjFilter, oParameterFilter],
                    success: function (oData) {
                        var oInboxModel = this.getModel("Inbox");
                        oInboxModel.setProperty("/PRs", oData.results);
                        var oControl = oInboxModel.getProperty("/oControl");
                        this.hideBusyControl(oControl);
                        oInboxModel.refresh(true);
                    }.bind(this),
                    error: function () { }
                });
            },

            // get header data item & form of PO scheduling page
            _readPOHeaderDetailItem: function (sProperty, sPONumber) {
                return new Promise((resolve, reject) => {
                    var operator = sap.ui.model.FilterOperator.EQ;
                    var oPONumberFilter = this.getFilter(sProperty, sPONumber, operator);
                    var oPRPOModel = this.getODataModel();
                    this.showBusyIndicator();
                    oPRPOModel.read("/POHeaderDetailsSet", {
                        filters: [oPONumberFilter],
                        success: function (oData) {
                            var oInboxModel = this.getModel("Inbox");
                            // oInboxModel.setProperty("/ItemCount", oData.results.length);
                            oData.results[0].ItemCount = oData.results[0].ItemCount.trim();
                            oInboxModel.setProperty("/oSelectedPO", oData.results[0]);
                            oInboxModel.setProperty("/ActiveList", "PO");
                            resolve(oData.results[0]);
                            this.hideBusyIndicator();
                        }.bind(this),
                        error: function () { 
                            this
                        }.bind(this)
                    });
                });
            },

            // on PO list item select (main view)
            onPOSelectionChange: async function (oEvent) {
                this.getModel("Inbox").setProperty("/oControl", oEvent.getSource());
                var oListItem = oEvent.mParameters.listItem;
                oListItem.setSelected(false);
                var oSelectedPO = oListItem.getBindingContext("Inbox").getObject();
                await this._readPOHeaderDetailItem("PoNumber", oSelectedPO.DocNumber);
                this.getRouter().navTo("POScheduling", {
                    PoNumber: oSelectedPO.DocNumber
                });
            },

            // on PR list item select (main View)
            onRequisitionSelectionChange: function (oEvent) {
                var oInboxModel = this.getModel("Inbox");
                oInboxModel.setProperty("/oControl", oEvent.getSource());
                var oPRItem = oEvent.mParameters.listItem;
                oPRItem.setSelected(false);
                var oSelectedPR = oPRItem.getBindingContext("Inbox").getObject();
                oInboxModel.setProperty("/SelectedPR", oSelectedPR);
                this.getRouter().navTo("RequisitionDetails", {
                    PrNumber: oSelectedPR.DocNumber
                });
            },

            // on purchase order btn press (footer)
            onPurchaseOrderPress: function () {
                var oInboxModel = this.getModel("Inbox");
                oInboxModel.setProperty("/ActiveList", "PO");
                oInboxModel.setProperty("/bVisibleInSearch", true);
                var sVisibleList = oInboxModel.getProperty("/ActiveList");
                sVisibleList === "PO" ? (this.getControl("POBtn").setType("Emphasized") && this.getControl("PRBtn").setType("Transparent")) : null;
                sVisibleList === "PO" ? this._readPOListItem("EmailId", this.getUserInfo()) : this._readPRListItem();

            },

            // on requisition btn press (footer)
            onRequisitionPress: function () {
                var oInboxModel = this.getModel("Inbox");
                oInboxModel.setProperty("/ActiveList", "REQ");
                oInboxModel.setProperty("/bVisibleInSearch", true);
                var sVisibleList = oInboxModel.getProperty("/ActiveList");
                sVisibleList === "REQ" ? (this.getControl("PRBtn").setType("Emphasized") && this.getControl("POBtn").setType("Transparent")) : null;
                sVisibleList === "REQ" ? this._readPRListItem() : this._readPOListItem("EmailId", this.getUserInfo());

            },

            // on filter icon press (filter dialog open)
            onFilterPress: function () {
                var oInboxModel = this.getModel("Inbox");
                var oSearchObj = Models.getSearchObj();
                oInboxModel.setProperty("/SearchObj", oSearchObj);
                oInboxModel.setProperty("/ControlType", "Dialog");
                var sVisibleList = oInboxModel.getProperty("/ActiveList");
                var sPath = sVisibleList === "PO" ? this.getFilterDialogPath(sVisibleList) : this.getFilterDialogPath(sVisibleList);
                if (!this.filterDialog) {
                    this.filterDialog = sap.ui.xmlfragment(sPath, this);
                    this.getView().addDependent(this.filterDialog);
                }
                this.filterDialog.open();
            },

            // used in onFilterGoPress function to get filter data (line no 221)
            getFilterData: function (filters) {
                var oPRPOModel = this.getModel();
                this.showBusyIndicator();
                oPRPOModel.read("/POWorkItemsSet", {
                    filters: filters,
                    success: function (oData) {
                        this.hideBusyIndicator();
                        var oInboxModel = this.getModel("Inbox");
                        var sVisibleList = oInboxModel.getProperty("/ActiveList");
                        oInboxModel.setProperty("/bVisibleInSearch", false);
                        oInboxModel.setProperty("/bRefreshed", false);
                        var sMessage;
                        var aResults = oData.results;
                        if (aResults.length === 0) {
                            if (sVisibleList === "PO") {
                                oInboxModel.setProperty("/POs", oData.results);
                                sMessage = "No PO data available for the given search criteria";
                            } else {
                                oInboxModel.setProperty("/PRs", oData.results);
                                sMessage = "No PR data available for the given search criteria";
                            }
                            MessageBox.information(sMessage, {
                                title: "Information"
                            });
                            oInboxModel.refresh(true);
                            return;
                        }
                        for (var r in aResults) {
                            if (!aResults[r].DocNumber || aResults[r].DocNumber === "") {
                                if (sVisibleList === "PO") {
                                    aResults[r].DocNumber = aResults[r].PoNumber;
                                } else {
                                    aResults[r].DocNumber = aResults[r].PrNumber;
                                }
                            }
                        }
                        sVisibleList === "PO" ? oInboxModel.setProperty("/POs", aResults) : oInboxModel.setProperty("/PRs", aResults);
                        var oControl = oInboxModel.getProperty("/oControl");
                        this.hideBusyControl(oControl);
                        oInboxModel.refresh(true);
                    }.bind(this),
                    error: function (oError) {
                        MessageBox.error("An error occured while retrieving data.");
                     }
                });
            },

            onFilterGoPress: function () {
                var oInboxModel = this.getModel("Inbox");
                var oSearchObj = oInboxModel.getProperty("/SearchObj");
                var sReleaseGroup = oSearchObj.RelGroup.trim();
                var sReleaseCode = oSearchObj.RelCode.trim();
                var sDocCategory = oSearchObj.PoDocCat.trim();
                var sPoOrganization = oSearchObj.PoPurchOrg.trim();
                var sPoGroup = oSearchObj.PoPurGroup.trim();
                var sPlant = oSearchObj.PrPlant.trim();
                var sPrGroup = oSearchObj.PrPurGroup.trim();
                var sMaterialGroup = oSearchObj.PrName1.trim();
                var sMaterialNumber = oSearchObj.PrMatNumber.trim();
                var sVendor = oSearchObj.PrVendor.trim();
                var sPrNumber = oSearchObj.PrNumber.trim();
                var sPoNumber = oSearchObj.PoNumber.trim();

                var aFilter = [];
                var operator = sap.ui.model.FilterOperator.EQ;

                var sVisibleList = oInboxModel.getProperty("/ActiveList");
                var sParameter = sVisibleList === "PO" ? "PO" : "PR";
                var sTaskObjNumber = sVisibleList === "PO" ? "TS99900033" : "TS99900012";
                var oUserIdFilter = this.getFilter("EmailId", this.getUserInfo(), operator);
                var oTaskObjFilter = this.getFilter("TaskObj", sTaskObjNumber, operator);
                var oParameterFilter = this.getFilter("Parameter", sParameter, operator);
                aFilter.push(oUserIdFilter, oTaskObjFilter, oParameterFilter);

                if (sReleaseGroup === "" && sReleaseCode === "" && sDocCategory === "" && sPoOrganization === "" && sPoGroup === "" && sPlant === "" && sPrGroup === "" && sMaterialGroup === "" && sMaterialNumber === "" && sVendor === "" && sPrNumber === "" && sPoNumber === "") {
                    var sMessage = "Please provide any search criteria";
                    MessageBox.information(sMessage, {
                        title: "Information"
                    });
                    return;
                }
                if (sReleaseGroup !== "") {
                    var oReleaseGroupFilter = this.getFilter("RelGroup", sReleaseGroup, operator);
                    aFilter.push(oReleaseGroupFilter);
                }
                if (sReleaseCode !== "") {
                    var oReleaseCodeFilter = this.getFilter("RelCode", sReleaseCode, operator);
                    aFilter.push(oReleaseCodeFilter);
                }
                if (sDocCategory !== "") {
                    var oDocCategoryFilter = this.getFilter("PoDocCat", sDocCategory, operator);
                    aFilter.push(oDocCategoryFilter);
                }
                if (sPoOrganization !== "") {
                    var oPoOrganizationFilter = this.getFilter("PoPurchOrg", sPoOrganization, operator);
                    aFilter.push(oPoOrganizationFilter);
                }
                if (sPoGroup !== "") {
                    var oPoGroupFilter = this.getFilter("PoPurGroup", sPoGroup, operator);
                    aFilter.push(oPoGroupFilter);
                }
                if (sPlant !== "") {
                    var oPlantFilter = this.getFilter("PrPlant", sPlant, operator);
                    aFilter.push(oPlantFilter);
                }
                if (sPrGroup !== "") {
                    var oPrGroupFilter = this.getFilter("PrPurGroup", sPrGroup, operator);
                    aFilter.push(oPrGroupFilter);
                }
                if (sMaterialGroup !== "") {
                    var oMaterialGroupFilter = this.getFilter("PrName1", sMaterialGroup, operator);
                    aFilter.push(oMaterialGroupFilter);
                }
                if (sMaterialNumber !== "") {
                    var oMaterialFilter = this.getFilter("PrMatNumber", sMaterialNumber, operator);
                    aFilter.push(oMaterialFilter);
                }
                if (sVendor !== "") {
                    var oVendorFilter = this.getFilter("PrVendor", sVendor, operator);
                    aFilter.push(oVendorFilter);
                }
                if (sPrNumber !== "") {
                    var oPrNumberFilter = this.getFilter("PrNumber", sPrNumber, operator);
                    aFilter.push(oPrNumberFilter);
                }
                if (sPoNumber !== "") {
                    var oPrNumberFilter = this.getFilter("PoNumber", sPoNumber, operator);
                    aFilter.push(oPrNumberFilter);
                }
               
                this.getFilterData(aFilter);
                this.onFilterCancelPress();
            },

            // filter dialog cancel press
            onFilterCancelPress: function () {
                this.filterDialog.close();
                if (this.filterDialog) {
                    this.filterDialog.destroy();
                    this.filterDialog = null;
                }
                this.getModel("Inbox").setProperty("/ControlType", undefined);
            },

            onRefresh: function () {
                var oInboxModel = this.getModel("Inbox");
                oInboxModel.setProperty("/bVisibleInSearch", true);
                oInboxModel.setProperty("/ControlType", undefined);
                var sVisibleList = oInboxModel.getProperty("/ActiveList");
                sVisibleList === "PO" ? this.onPurchaseOrderPress() : this.onRequisitionPress();
            }
        });
    });
