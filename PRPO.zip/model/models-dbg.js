sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device"
],
    function (JSONModel, Device) {
        "use strict";

        return {
            /**
             * Provides runtime info for the device the UI5 app is running on as JSONModel
             */
            createDeviceModel: function () {
                var oModel = new JSONModel(Device);
                oModel.setDefaultBindingMode("OneWay");
                return oModel;
            },

            getPOApprovalObj: function () {
                return {
                    "PoNumber": "",
                    "Type": "",
                    "Code": "",
                    "Message": "",
                    "LogNo": "",
                    "LogMsgNo": "",
                    "MessageV1": "",
                    "MessageV2": "",
                    "MessageV3": "",
                    "MessageV4": "",
                    "PoRelCod": "",
                    "RelStatus": "",
                    "RetCode": "",
                    "PoRelInd": ""
                };
            },

            getPORejectionObj: function () {
                return {
                    "PoNumber": "",
                    "Type": "",
                    "Id": "",
                    "Number": "",
                    "Message": "",
                    "LogNo": "",
                    "LogMsgNo": "",
                    "MessageV1": "",
                    "MessageV2": "",
                    "MessageV3": "",
                    "MessageV4": ""
                };
            },

            getPRApprovalObj: function () {
                return {
                    "PrNumber": "",
                    "RelCode": "",
                    "RelStatusNew": "",
                    "RelIndicatorNew": "",
                    "Type": "",
                    "Message": ""
                };
            },

            getPRRejectionObj: function () {
                return {
                    "PrNumber": "",
                    "Type": "",
                    "Message": ""
                };
            },

            getSearchObj: function () {
                return {
                    "RelGroup": "",
                    "RelCode": "",
                    "PoDocCat": "",
                    "PoPurchOrg": "",
                    "PoPurGroup": "",
                    "PrPlant": "",
                    "PrPurGroup": "",
                    "PrName1": "",
                    "PrMatNumber":"",
                    "PrVendor": "",
                    "PoNumber":"",
                    "PrNumber":""
                };
            }
        };

    });