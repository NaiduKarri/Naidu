sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
  ],
  function (BaseController, MessageToast, MessageBox, Filter, FilterOperator) {
    "use strict";

    return BaseController.extend("zprpoinbox.controller.App", {

      getRouter: function () {
        return this.getOwnerComponent().getRouter();
      },

      getODataModel: function () {
        return this.getOwnerComponent().getModel();
      },

      getModel: function (sName) {
        return this.getOwnerComponent().getModel(sName);
      },

      setModel: function (oModel, sName) {
        return this.getView().setModel(oModel, sName);
      },

      getResourceBundle: function () {
        return this.getOwnerComponent().getModel("i18n").getResourceBundle();
      },

      getControl: function (sId) {
        var sControlType = this.getModel("Inbox").getProperty("/ControlType");
        return sControlType === "Dialog" ? sap.ui.getCore().byId(sId) : this.byId(sId);
      },

      showBusyIndicator: function (iMilliSeconds) {
        var iDelay = iMilliSeconds || 0;
        sap.ui.core.BusyIndicator.show(iDelay);
      },

      hideBusyIndicator: function () {
        sap.ui.core.BusyIndicator.hide();
      },

      showBusyControl: function (oControl, iMilliSeconds) {
        var iDelay = iMilliSeconds || 0
        oControl.setBusyIndicatorDelay(iDelay);
        oControl.setBusy(true);
      },

      hideBusyControl: function (oControl) {
        oControl.setBusy(false);
      },

      setMessageToast: function (sMessage) {
        return MessageToast.show(sMessage);
      },

      setSuccessMessageBox: function (sMessage) {
        return MessageBox.success(sMessage, {
          title: "Success",
        });
      },

      getFilter: function (sPath, value1, operator) {
        return new sap.ui.model.Filter({
          path: sPath,
          operator: operator,
          value1: value1
        });
      },

      closeApproveMsgDialog: function () {
        this.oApproveMsgDialog.close();
        if (this.oApproveMsgDialog) {
          this.oApproveMsgDialog.destroy();
          this.oApproveMsgDialog = null;
        }
      },

      closeRejectMsgDialog: function () {
        this.oRejectMsgDialog.close();
        if (this.oRejectMsgDialog) {
          this.oRejectMsgDialog.destroy();
          this.oRejectMsgDialog = null;
        }
      },

      // used for getting path for respective dialogs
      getFilterDialogPath: function (sVisibleList) {
        var sPath;
        switch (sVisibleList) {
          case "PO":
            sPath = "zprpoinbox.fragments.POFilter";
            return sPath;
          case "REQ":
            sPath = "zprpoinbox.fragments.PRFilter";
            return sPath;

        }
      },


    });
  }
);
