sap.ui.define([
    "./App.controller"
],
    function (Controller) {
        "use strict";

        return Controller.extend("zprpoinbox.controller.DisplayPOHeaderTable", {

            onInit: function () { },

            // onDisplayPOHeaderTableNavPress: function () {
            //     var sPoNumber = this.getModel("Inbox").getProperty("/PoNumber");
            //     this.getRouter().navTo("POScheduling", {
            //         PoNumber: sPoNumber
            //     });
            // }
        });
    });
